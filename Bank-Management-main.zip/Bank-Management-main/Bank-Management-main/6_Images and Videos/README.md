## First output after running makefile
![Screenshot (126)](https://user-images.githubusercontent.com/65857693/132501214-d15d4715-b482-40e6-bd45-90e4f3d45959.png)

## It asks for Choice of user
![Screenshot (127)](https://user-images.githubusercontent.com/65857693/132501249-ed9c6117-df18-4dff-9bfb-00b69b968604.png)
## If user enters 1 then it asks details to open new account

![Screenshot (128)](https://user-images.githubusercontent.com/65857693/132500927-909ebe43-6edb-414c-8db9-6119a534e320.png)
## If user enters 2 as existing User then he gets following Actions
![Screenshot (129)](https://user-images.githubusercontent.com/65857693/132500964-fe737389-78e6-4b16-b61c-6294547d5d80.png)
## Depositing amount
![Screenshot (130)](https://user-images.githubusercontent.com/65857693/132500983-f5a9fe7f-b2e7-4f60-bbb2-2e34e9e533df.png)
## Withrawing Amount
![Screenshot (131)](https://user-images.githubusercontent.com/65857693/132500998-6943c481-63df-4e50-8eb6-69c859d6535c.png)
## Foreign Exchange
![Screenshot (132)](https://user-images.githubusercontent.com/65857693/132501006-ad309e57-970b-4264-801a-c2140b9f82ae.png)


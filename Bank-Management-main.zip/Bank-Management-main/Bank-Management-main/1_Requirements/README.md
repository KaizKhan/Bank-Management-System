# Requirements
## Introduction
 --- Bank Management system : With this project, user can perform banking activities like in real bank. This perticular file contains all the details of requirement collection from user end.


## SWOT ANALYSIS
**Strength**
-- User can have all the banking Activities.
  * Depositing Amount
  * Withdrawing Amount
  * Viewing Details
  * Foreign Exchange  

**Weakness**
-- If the password is wrong No activities can be done.

**Opportunity**
-- user can Deposit, withdraw amount and can view details.

**Threats**
-- If the password is wrong No activities can be done.

# 4W&#39;s and 1&#39;H

## Who:

**Everyone can use the bank management system who want to have benifit of banking.**

## What:

**Bank management sysem is mainly concerned to Cover the major Banking activities in sigle application.**

## When:

**TBD**

## Where:

**User can can access this application using any C compiler.**

## How:

**Implementation is done using C language. And also used multifile concept.**

# Detail requirements
## High Level Requirements:
-- ID | Description | Status (Implemented/Future)
----- | ------------|---------------------------
HLR1| System Shall be able to open new Account | Implemented
HLR2| User shall Deposit Money| Implemented
HLR3| User shall Withdraw Money| Implemented
HLR4| User shall View Details| Implemented



##  Low level Requirements:
-- ID | Description | Status (Implemented/Future)
----- | ------------|---------------------------
LLR1| User can have transaction only if user has Account | Implemented
LLR2| System Shall be able to open new Account | Implemented

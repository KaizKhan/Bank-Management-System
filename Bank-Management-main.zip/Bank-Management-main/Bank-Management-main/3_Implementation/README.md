# Implementation

## Folder Structure
Folder        | description
--------------| ----------------------------------------------
`inc`         | All header files
`src`         | Main source code for calculator
`test`        | All source code and data for testing purposes
`unity`        | All source code which are required for unit testing
`makefie`        | makefile of the project
`Project_main.c`        | main source code 




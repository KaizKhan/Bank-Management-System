    /**
     * @brief function to convert rupee to euro     * 
     * @param x2 
     * @param x3 
     * @return float 
     */
    float euro(int x2, int x3)
    {

        return (float)x2 / x3;
    }
/**
 * @brief function to convert rupees to dollar
 * 
 * @param x 
 * @param x1 
 * @return float 
 */
    float dollar(int x, int x1)
    {

        return (float)x / x1;
    }
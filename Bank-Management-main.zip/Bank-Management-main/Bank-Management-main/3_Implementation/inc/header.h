#include "bank.h"
 #include<stdio.h>  
 #include<dos.h>  
 #include<conio.h>  
 #include<string.h>  
 #include<process.h>  
 struct bank // Bank Structure  
 {
 int accno;  
 char name[20];  
 float bal;  
 }b;  
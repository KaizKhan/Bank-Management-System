#ifndef __DOLLAR_H
#define __DOLLAR_H

#include "assert.h"
#include "stdio.h"

float dollar(int x, int x1);

#endif

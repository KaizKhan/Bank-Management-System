#ifndef __EURO_H
#define __EURO_H

#include "assert.h"
#include "stdio.h"

float euro(int x2, int x3);

#endif

#ifndef __BANK_H
#define __BANK_H

#include "assert.h"
#include "stdio.h"

void new_customer();
void existing_customer();
float dollar(int x, int x1);

#endif



# High level Design
## Figure 1.1 Use Case Diagram
![usecasebank drawio](https://user-images.githubusercontent.com/65857693/132243661-f8feedc7-5bea-4554-a52c-911d67b21a51.png)
# Low Level Design
## Figure 1.2 Activity Diagram
![Activitybm drawio](https://user-images.githubusercontent.com/65857693/132243991-2f3738c1-0d04-4a1b-9604-afdf0f9b3ce6.png)



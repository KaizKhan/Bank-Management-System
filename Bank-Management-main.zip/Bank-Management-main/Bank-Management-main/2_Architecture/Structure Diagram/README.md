# High Level Design
## Architecture diagram
![Untitled Diagram drawio (1)](https://user-images.githubusercontent.com/65857693/132499421-3edb8bf2-ae4c-47c3-abaf-b0c77ecf1501.png)


# Low level Design
## 2.2 Data Flow Diagram 
![Untitled Diagram drawio](https://user-images.githubusercontent.com/65857693/132315333-4d925465-ad47-4408-bccb-705de4af0cda.png)


